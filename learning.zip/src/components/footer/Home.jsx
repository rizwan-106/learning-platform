import React from "react";
import CourseCard from "../CourseCard";
import Footer1 from "./Footer1";

const Home = () => {
  return (
    <div>
      <CourseCard />
      {/* <Footer1 /> */}
    </div>
  );
};

export default Home;
